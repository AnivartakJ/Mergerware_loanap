module.export({STATUS_NONE:()=>STATUS_NONE,STATUS_APPEAR:()=>STATUS_APPEAR,STATUS_ENTER:()=>STATUS_ENTER,STATUS_LEAVE:()=>STATUS_LEAVE,STEP_NONE:()=>STEP_NONE,STEP_PREPARE:()=>STEP_PREPARE,STEP_START:()=>STEP_START,STEP_ACTIVE:()=>STEP_ACTIVE,STEP_ACTIVATED:()=>STEP_ACTIVATED,STEP_PREPARED:()=>STEP_PREPARED});var STATUS_NONE = 'none';
var STATUS_APPEAR = 'appear';
var STATUS_ENTER = 'enter';
var STATUS_LEAVE = 'leave';
var STEP_NONE = 'none';
var STEP_PREPARE = 'prepare';
var STEP_START = 'start';
var STEP_ACTIVE = 'active';
var STEP_ACTIVATED = 'end';
/**
 * Used for disabled motion case.
 * Prepare stage will still work but start & active will be skipped.
 */
var STEP_PREPARED = 'prepared';