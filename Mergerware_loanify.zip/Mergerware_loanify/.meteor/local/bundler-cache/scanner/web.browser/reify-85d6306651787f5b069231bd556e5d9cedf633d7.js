let _extends;module.link("@babel/runtime/helpers/esm/extends",{default(v){_extends=v}},0);let React;module.link('react',{"*"(v){React=v}},1);let InfoCircleFilledSvg;module.link("@ant-design/icons-svg/es/asn/InfoCircleFilled",{default(v){InfoCircleFilledSvg=v}},2);let AntdIcon;module.link("../components/AntdIcon",{default(v){AntdIcon=v}},3);
// GENERATE BY ./scripts/generate.ts
// DON NOT EDIT IT MANUALLY




var InfoCircleFilled = function InfoCircleFilled(props, ref) {
  return /*#__PURE__*/React.createElement(AntdIcon, _extends({}, props, {
    ref: ref,
    icon: InfoCircleFilledSvg
  }));
};
if (process.env.NODE_ENV !== 'production') {
  InfoCircleFilled.displayName = 'InfoCircleFilled';
}
module.exportDefault(React.forwardRef(InfoCircleFilled));