let useStyleRegister;module.link('@ant-design/cssinjs',{useStyleRegister(v){useStyleRegister=v}},0);let resetIcon;module.link('../../style',{resetIcon(v){resetIcon=v}},1);let useToken;module.link('../useToken',{default(v){useToken=v}},2);


const useResetIconStyle = (iconPrefixCls, csp) => {
  const [theme, token] = useToken();
  // Generate style for icons
  return useStyleRegister({
    theme,
    token,
    hashId: '',
    path: ['ant-design-icons', iconPrefixCls],
    nonce: () => csp === null || csp === void 0 ? void 0 : csp.nonce
  }, () => [{
    [`.${iconPrefixCls}`]: Object.assign(Object.assign({}, resetIcon()), {
      [`.${iconPrefixCls} .${iconPrefixCls}-icon`]: {
        display: 'block'
      }
    })
  }]);
};
module.exportDefault(useResetIconStyle);