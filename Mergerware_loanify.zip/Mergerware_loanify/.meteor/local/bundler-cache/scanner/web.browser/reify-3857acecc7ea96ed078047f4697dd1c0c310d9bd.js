"use client";module.export({DisabledContextProvider:()=>DisabledContextProvider},true);let React;module.link('react',{"*"(v){React=v}},0);


const DisabledContext = /*#__PURE__*/React.createContext(false);
const DisabledContextProvider = _ref => {
  let {
    children,
    disabled
  } = _ref;
  const originDisabled = React.useContext(DisabledContext);
  return /*#__PURE__*/React.createElement(DisabledContext.Provider, {
    value: disabled !== null && disabled !== void 0 ? disabled : originDisabled
  }, children);
};
module.exportDefault(DisabledContext);