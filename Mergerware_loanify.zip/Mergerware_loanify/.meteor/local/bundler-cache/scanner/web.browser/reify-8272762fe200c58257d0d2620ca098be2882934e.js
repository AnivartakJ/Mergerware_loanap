let _createClass;module.link("@babel/runtime/helpers/esm/createClass",{default(v){_createClass=v}},0);let _classCallCheck;module.link("@babel/runtime/helpers/esm/classCallCheck",{default(v){_classCallCheck=v}},1);

let AbstractCalculator = /*#__PURE__*/_createClass(function AbstractCalculator() {
  _classCallCheck(this, AbstractCalculator);
});
module.exportDefault(AbstractCalculator);