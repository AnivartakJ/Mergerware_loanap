let React;module.link('react',{default(v){React=v}},0);
const zIndexContext = /*#__PURE__*/React.createContext(undefined);
if (process.env.NODE_ENV !== 'production') {
  zIndexContext.displayName = 'zIndexContext';
}
module.exportDefault(zIndexContext);