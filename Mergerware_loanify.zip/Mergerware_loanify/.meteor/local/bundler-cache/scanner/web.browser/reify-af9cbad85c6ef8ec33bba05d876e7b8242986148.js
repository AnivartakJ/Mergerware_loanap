module.export({getAlphaColor:()=>getAlphaColor,getSolidColor:()=>getSolidColor},true);let TinyColor;module.link('@ctrl/tinycolor',{TinyColor(v){TinyColor=v}},0);
const getAlphaColor = (baseColor, alpha) => new TinyColor(baseColor).setAlpha(alpha).toRgbString();
const getSolidColor = (baseColor, brightness) => {
  const instance = new TinyColor(baseColor);
  return instance.darken(brightness).toHexString();
};