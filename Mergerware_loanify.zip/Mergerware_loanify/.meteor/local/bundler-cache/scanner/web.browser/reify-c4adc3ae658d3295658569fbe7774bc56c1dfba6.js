module.export({useNotification:()=>useNotification,Notice:()=>Notice,NotificationProvider:()=>NotificationProvider});let useNotification;module.link("./hooks/useNotification",{default(v){useNotification=v}},0);let Notice;module.link("./Notice",{default(v){Notice=v}},1);let NotificationProvider;module.link("./NotificationProvider",{default(v){NotificationProvider=v}},2);


