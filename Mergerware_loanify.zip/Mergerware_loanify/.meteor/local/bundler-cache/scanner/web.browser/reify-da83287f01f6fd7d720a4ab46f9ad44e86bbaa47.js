module.export({defaultTheme:()=>defaultTheme,defaultConfig:()=>defaultConfig,DesignTokenContext:()=>DesignTokenContext},true);let React;module.link('react',{default(v){React=v}},0);let createTheme;module.link('@ant-design/cssinjs',{createTheme(v){createTheme=v}},1);let defaultDerivative;module.link('./themes/default',{default(v){defaultDerivative=v}},2);let defaultSeedToken;module.link('./themes/seed',{default(v){defaultSeedToken=v}},3);



const defaultTheme = createTheme(defaultDerivative);
// ================================ Context =================================
// To ensure snapshot stable. We disable hashed in test env.
const defaultConfig = {
  token: defaultSeedToken,
  override: {
    override: defaultSeedToken
  },
  hashed: true
};
const DesignTokenContext = /*#__PURE__*/React.createContext(defaultConfig);