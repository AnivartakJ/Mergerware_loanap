let _extends;module.link("@babel/runtime/helpers/esm/extends",{default(v){_extends=v}},0);let React;module.link('react',{"*"(v){React=v}},1);let CloseCircleFilledSvg;module.link("@ant-design/icons-svg/es/asn/CloseCircleFilled",{default(v){CloseCircleFilledSvg=v}},2);let AntdIcon;module.link("../components/AntdIcon",{default(v){AntdIcon=v}},3);
// GENERATE BY ./scripts/generate.ts
// DON NOT EDIT IT MANUALLY




var CloseCircleFilled = function CloseCircleFilled(props, ref) {
  return /*#__PURE__*/React.createElement(AntdIcon, _extends({}, props, {
    ref: ref,
    icon: CloseCircleFilledSvg
  }));
};
if (process.env.NODE_ENV !== 'production') {
  CloseCircleFilled.displayName = 'CloseCircleFilled';
}
module.exportDefault(React.forwardRef(CloseCircleFilled));