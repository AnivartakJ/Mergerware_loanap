module.export({default:()=>_createSuper});let getPrototypeOf;module.link("./getPrototypeOf.js",{default(v){getPrototypeOf=v}},0);let isNativeReflectConstruct;module.link("./isNativeReflectConstruct.js",{default(v){isNativeReflectConstruct=v}},1);let possibleConstructorReturn;module.link("./possibleConstructorReturn.js",{default(v){possibleConstructorReturn=v}},2);


function _createSuper(Derived) {
  var hasNativeReflectConstruct = isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = getPrototypeOf(Derived),
      result;
    if (hasNativeReflectConstruct) {
      var NewTarget = getPrototypeOf(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return possibleConstructorReturn(this, result);
  };
}