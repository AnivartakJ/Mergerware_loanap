module.link('../../theme/internal',{useResetIconStyle:"default"},0);// eslint-disable-next-line no-restricted-exports
