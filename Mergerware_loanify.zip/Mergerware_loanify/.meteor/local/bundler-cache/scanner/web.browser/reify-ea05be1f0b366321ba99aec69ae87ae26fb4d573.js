let React;module.link('react',{"*"(v){React=v}},0);
const fullClone = Object.assign({}, React);
const {
  useId
} = fullClone;
const useEmptyId = () => '';
const useThemeKey = typeof useId === 'undefined' ? useEmptyId : useId;
module.exportDefault(useThemeKey);