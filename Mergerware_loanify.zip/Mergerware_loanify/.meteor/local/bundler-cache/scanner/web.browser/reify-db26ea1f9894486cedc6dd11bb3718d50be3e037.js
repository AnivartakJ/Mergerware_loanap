module.export({default:()=>useWave});let React;module.link('react',{"*"(v){React=v}},0);let useEvent;module.link('rc-util',{useEvent(v){useEvent=v}},1);let raf;module.link("rc-util/es/raf",{default(v){raf=v}},2);let showWaveEffect;module.link('./WaveEffect',{default(v){showWaveEffect=v}},3);let ConfigContext;module.link('../../config-provider',{ConfigContext(v){ConfigContext=v}},4);let useToken;module.link('../../theme/useToken',{default(v){useToken=v}},5);let TARGET_CLS;module.link('./interface',{TARGET_CLS(v){TARGET_CLS=v}},6);






function useWave(nodeRef, className, component) {
  const {
    wave
  } = React.useContext(ConfigContext);
  const [, token, hashId] = useToken();
  const showWave = useEvent(event => {
    const node = nodeRef.current;
    if ((wave === null || wave === void 0 ? void 0 : wave.disabled) || !node) {
      return;
    }
    const targetNode = node.querySelector(`.${TARGET_CLS}`) || node;
    const {
      showEffect
    } = wave || {};
    // Customize wave effect
    (showEffect || showWaveEffect)(targetNode, {
      className,
      token,
      component,
      event,
      hashId
    });
  });
  const rafId = React.useRef();
  // Merge trigger event into one for each frame
  const showDebounceWave = event => {
    raf.cancel(rafId.current);
    rafId.current = raf(() => {
      showWave(event);
    });
  };
  return showDebounceWave;
}