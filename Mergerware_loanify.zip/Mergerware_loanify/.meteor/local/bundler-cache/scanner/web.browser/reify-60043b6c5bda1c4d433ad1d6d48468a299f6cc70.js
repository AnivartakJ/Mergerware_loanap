module.export({Theme:()=>Theme,createTheme:()=>createTheme,useStyleRegister:()=>useStyleRegister,useCSSVarRegister:()=>useCSSVarRegister,useCacheToken:()=>useCacheToken,createCache:()=>createCache,StyleProvider:()=>StyleProvider,Keyframes:()=>Keyframes,extractStyle:()=>extractStyle,getComputedToken:()=>getComputedToken,legacyLogicalPropertiesTransformer:()=>legacyLogicalPropertiesTransformer,px2remTransformer:()=>px2remTransformer,logicalPropertiesLinter:()=>logicalPropertiesLinter,legacyNotSelectorLinter:()=>legacyNotSelectorLinter,parentSelectorLinter:()=>parentSelectorLinter,NaNLinter:()=>NaNLinter,token2CSSVar:()=>token2CSSVar,unit:()=>unit,_experimental:()=>_experimental});let extractStyle;module.link("./extractStyle",{default(v){extractStyle=v}},0);let useCacheToken,getComputedToken;module.link("./hooks/useCacheToken",{default(v){useCacheToken=v},getComputedToken(v){getComputedToken=v}},1);let useCSSVarRegister;module.link("./hooks/useCSSVarRegister",{default(v){useCSSVarRegister=v}},2);let useStyleRegister;module.link("./hooks/useStyleRegister",{default(v){useStyleRegister=v}},3);let Keyframes;module.link("./Keyframes",{default(v){Keyframes=v}},4);let legacyNotSelectorLinter,logicalPropertiesLinter,NaNLinter,parentSelectorLinter;module.link("./linters",{legacyNotSelectorLinter(v){legacyNotSelectorLinter=v},logicalPropertiesLinter(v){logicalPropertiesLinter=v},NaNLinter(v){NaNLinter=v},parentSelectorLinter(v){parentSelectorLinter=v}},5);let createCache,StyleProvider;module.link("./StyleContext",{createCache(v){createCache=v},StyleProvider(v){StyleProvider=v}},6);let createTheme,Theme;module.link("./theme",{createTheme(v){createTheme=v},Theme(v){Theme=v}},7);let legacyLogicalPropertiesTransformer;module.link("./transformers/legacyLogicalProperties",{default(v){legacyLogicalPropertiesTransformer=v}},8);let px2remTransformer;module.link("./transformers/px2rem",{default(v){px2remTransformer=v}},9);let supportLogicProps,supportWhere,unit;module.link("./util",{supportLogicProps(v){supportLogicProps=v},supportWhere(v){supportWhere=v},unit(v){unit=v}},10);let token2CSSVar;module.link("./util/css-variables",{token2CSSVar(v){token2CSSVar=v}},11);


















var _experimental = {
  supportModernCSS: function supportModernCSS() {
    return supportWhere() && supportLogicProps();
  }
};