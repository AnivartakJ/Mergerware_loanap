module.export({_rs:()=>_rs});let _extends;module.link("@babel/runtime/helpers/esm/extends",{default(v){_extends=v}},0);let React;module.link('react',{"*"(v){React=v}},1);let toArray;module.link("rc-util/es/Children/toArray",{default(v){toArray=v}},2);let warning;module.link("rc-util/es/warning",{warning(v){warning=v}},3);let SingleObserver;module.link("./SingleObserver",{default(v){SingleObserver=v}},4);let Collection;module.link("./Collection",{Collection(v){Collection=v}},5);let _rs;module.link("./utils/observerUtil",{_rs(v){_rs=v}},6);





var INTERNAL_PREFIX_KEY = 'rc-observer-key';



function ResizeObserver(props, ref) {
  var children = props.children;
  var childNodes = typeof children === 'function' ? [children] : toArray(children);
  if (process.env.NODE_ENV !== 'production') {
    if (childNodes.length > 1) {
      warning(false, 'Find more than one child node with `children` in ResizeObserver. Please use ResizeObserver.Collection instead.');
    } else if (childNodes.length === 0) {
      warning(false, '`children` of ResizeObserver is empty. Nothing is in observe.');
    }
  }
  return childNodes.map(function (child, index) {
    var key = (child === null || child === void 0 ? void 0 : child.key) || "".concat(INTERNAL_PREFIX_KEY, "-").concat(index);
    return /*#__PURE__*/React.createElement(SingleObserver, _extends({}, props, {
      key: key,
      ref: index === 0 ? ref : undefined
    }), child);
  });
}
var RefResizeObserver = /*#__PURE__*/React.forwardRef(ResizeObserver);
if (process.env.NODE_ENV !== 'production') {
  RefResizeObserver.displayName = 'ResizeObserver';
}
RefResizeObserver.Collection = Collection;
module.exportDefault(RefResizeObserver);