module.export({Context:()=>Context,default:()=>MotionProvider});let _objectWithoutProperties;module.link("@babel/runtime/helpers/esm/objectWithoutProperties",{default(v){_objectWithoutProperties=v}},0);let React;module.link('react',{"*"(v){React=v}},1);
var _excluded = ["children"];

var Context = /*#__PURE__*/React.createContext({});
function MotionProvider(_ref) {
  var children = _ref.children,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(Context.Provider, {
    value: props
  }, children);
}