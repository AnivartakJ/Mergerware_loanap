let React;module.link('react',{"*"(v){React=v}},0);let LocaleContext;module.link('./context',{default(v){LocaleContext=v}},1);let defaultLocaleData;module.link('./en_US',{default(v){defaultLocaleData=v}},2);


const useLocale = (componentName, defaultLocale) => {
  const fullLocale = React.useContext(LocaleContext);
  const getLocale = React.useMemo(() => {
    var _a;
    const locale = defaultLocale || defaultLocaleData[componentName];
    const localeFromContext = (_a = fullLocale === null || fullLocale === void 0 ? void 0 : fullLocale[componentName]) !== null && _a !== void 0 ? _a : {};
    return Object.assign(Object.assign({}, typeof locale === 'function' ? locale() : locale), localeFromContext || {});
  }, [componentName, defaultLocale, fullLocale]);
  const getLocaleCode = React.useMemo(() => {
    const localeCode = fullLocale === null || fullLocale === void 0 ? void 0 : fullLocale.locale;
    // Had use LocaleProvide but didn't set locale
    if ((fullLocale === null || fullLocale === void 0 ? void 0 : fullLocale.exist) && !localeCode) {
      return defaultLocaleData.locale;
    }
    return localeCode;
  }, [fullLocale]);
  return [getLocale, getLocaleCode];
};
module.exportDefault(useLocale);