module.link("./hooks/useEvent",{default:"useEvent"},0);module.link("./hooks/useMergedState",{default:"useMergedState"},1);module.link("./ref",{supportNodeRef:"supportNodeRef",supportRef:"supportRef",useComposeRef:"useComposeRef"},2);module.link("./utils/get",{default:"get"},3);module.link("./utils/set",{default:"set"},4);module.link("./warning",{default:"warning"},5);




