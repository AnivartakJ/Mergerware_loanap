let _extends;module.link("@babel/runtime/helpers/esm/extends",{default(v){_extends=v}},0);let React;module.link('react',{"*"(v){React=v}},1);let LoadingOutlinedSvg;module.link("@ant-design/icons-svg/es/asn/LoadingOutlined",{default(v){LoadingOutlinedSvg=v}},2);let AntdIcon;module.link("../components/AntdIcon",{default(v){AntdIcon=v}},3);
// GENERATE BY ./scripts/generate.ts
// DON NOT EDIT IT MANUALLY




var LoadingOutlined = function LoadingOutlined(props, ref) {
  return /*#__PURE__*/React.createElement(AntdIcon, _extends({}, props, {
    ref: ref,
    icon: LoadingOutlinedSvg
  }));
};
if (process.env.NODE_ENV !== 'production') {
  LoadingOutlined.displayName = 'LoadingOutlined';
}
module.exportDefault(React.forwardRef(LoadingOutlined));