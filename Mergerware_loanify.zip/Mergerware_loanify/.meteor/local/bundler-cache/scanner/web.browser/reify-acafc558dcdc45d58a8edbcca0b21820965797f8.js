"use client";module.export({TypeIcon:()=>TypeIcon,PureContent:()=>PureContent},true);let CheckCircleFilled;module.link("@ant-design/icons/es/icons/CheckCircleFilled",{default(v){CheckCircleFilled=v}},0);let CloseCircleFilled;module.link("@ant-design/icons/es/icons/CloseCircleFilled",{default(v){CloseCircleFilled=v}},1);let ExclamationCircleFilled;module.link("@ant-design/icons/es/icons/ExclamationCircleFilled",{default(v){ExclamationCircleFilled=v}},2);let InfoCircleFilled;module.link("@ant-design/icons/es/icons/InfoCircleFilled",{default(v){InfoCircleFilled=v}},3);let LoadingOutlined;module.link("@ant-design/icons/es/icons/LoadingOutlined",{default(v){LoadingOutlined=v}},4);let classNames;module.link('classnames',{default(v){classNames=v}},5);let Notice;module.link('rc-notification',{Notice(v){Notice=v}},6);let React;module.link('react',{"*"(v){React=v}},7);let ConfigContext;module.link('../config-provider',{ConfigContext(v){ConfigContext=v}},8);let useStyle;module.link('./style',{default(v){useStyle=v}},9);let useCSSVarCls;module.link('../config-provider/hooks/useCSSVarCls',{default(v){useCSSVarCls=v}},10);

var __rest = this && this.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};











const TypeIcon = {
  info: /*#__PURE__*/React.createElement(InfoCircleFilled, null),
  success: /*#__PURE__*/React.createElement(CheckCircleFilled, null),
  error: /*#__PURE__*/React.createElement(CloseCircleFilled, null),
  warning: /*#__PURE__*/React.createElement(ExclamationCircleFilled, null),
  loading: /*#__PURE__*/React.createElement(LoadingOutlined, null)
};
const PureContent = _ref => {
  let {
    prefixCls,
    type,
    icon,
    children
  } = _ref;
  return /*#__PURE__*/React.createElement("div", {
    className: classNames(`${prefixCls}-custom-content`, `${prefixCls}-${type}`)
  }, icon || TypeIcon[type], /*#__PURE__*/React.createElement("span", null, children));
};
/** @private Internal Component. Do not use in your production. */
const PurePanel = props => {
  const {
      prefixCls: staticPrefixCls,
      className,
      type,
      icon,
      content
    } = props,
    restProps = __rest(props, ["prefixCls", "className", "type", "icon", "content"]);
  const {
    getPrefixCls
  } = React.useContext(ConfigContext);
  const prefixCls = staticPrefixCls || getPrefixCls('message');
  const rootCls = useCSSVarCls(prefixCls);
  const [wrapCSSVar, hashId, cssVarCls] = useStyle(prefixCls, rootCls);
  return wrapCSSVar( /*#__PURE__*/React.createElement(Notice, Object.assign({}, restProps, {
    prefixCls: prefixCls,
    className: classNames(className, hashId, `${prefixCls}-notice-pure-panel`, cssVarCls, rootCls),
    eventKey: "pure",
    duration: null,
    content: /*#__PURE__*/React.createElement(PureContent, {
      prefixCls: prefixCls,
      type: type,
      icon: icon
    }, content)
  })));
};
module.exportDefault(PurePanel);