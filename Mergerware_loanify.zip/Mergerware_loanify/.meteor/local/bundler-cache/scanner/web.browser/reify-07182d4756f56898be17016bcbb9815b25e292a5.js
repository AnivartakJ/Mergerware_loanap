"use client";let version;module.link('./version',{default(v){version=v}},0);

/* eslint import/no-unresolved: 0 */
// @ts-ignore

module.exportDefault(version);