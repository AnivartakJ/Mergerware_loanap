"use client";let React,forwardRef;module.link('react',{default(v){React=v},forwardRef(v){forwardRef=v}},0);let classNames;module.link('classnames',{default(v){classNames=v}},1);



const IconWrapper = /*#__PURE__*/forwardRef((props, ref) => {
  const {
    className,
    style,
    children,
    prefixCls
  } = props;
  const iconWrapperCls = classNames(`${prefixCls}-icon`, className);
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    className: iconWrapperCls,
    style: style
  }, children);
});
module.exportDefault(IconWrapper);