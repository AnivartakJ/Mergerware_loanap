module.export({inlineMock:()=>inlineMock});let Portal;module.link("./Portal",{default(v){Portal=v}},0);let inlineMock;module.link("./mock",{inlineMock(v){inlineMock=v}},1);


module.exportDefault(Portal);