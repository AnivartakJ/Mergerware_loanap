module.export({prepareComponentToken:()=>prepareComponentToken},true);let genStyleHooks;module.link('../../theme/internal',{genStyleHooks(v){genStyleHooks=v}},0);
// ============================== Shared ==============================
const genSharedAffixStyle = token => {
  const {
    componentCls
  } = token;
  return {
    [componentCls]: {
      position: 'fixed',
      zIndex: token.zIndexPopup
    }
  };
};
const prepareComponentToken = token => ({
  zIndexPopup: token.zIndexBase + 10
});
// ============================== Export ==============================
module.exportDefault(genStyleHooks('Affix', genSharedAffixStyle, prepareComponentToken));