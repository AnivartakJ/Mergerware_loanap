module.export({Panel:()=>Panel});let DialogWrap;module.link("./DialogWrap",{default(v){DialogWrap=v}},0);let Panel;module.link("./Dialog/Content/Panel",{default(v){Panel=v}},1);


module.exportDefault(DialogWrap);