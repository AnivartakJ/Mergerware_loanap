"use client";module.export({default:()=>MotionWrapper});let MotionProvider;module.link('rc-motion',{Provider(v){MotionProvider=v}},0);let React;module.link('react',{"*"(v){React=v}},1);let useToken;module.link('../theme/internal',{useToken(v){useToken=v}},2);




function MotionWrapper(props) {
  const {
    children
  } = props;
  const [, token] = useToken();
  const {
    motion
  } = token;
  const needWrapMotionProviderRef = React.useRef(false);
  needWrapMotionProviderRef.current = needWrapMotionProviderRef.current || motion === false;
  if (needWrapMotionProviderRef.current) {
    return /*#__PURE__*/React.createElement(MotionProvider, {
      motion: motion
    }, children);
  }
  return children;
}