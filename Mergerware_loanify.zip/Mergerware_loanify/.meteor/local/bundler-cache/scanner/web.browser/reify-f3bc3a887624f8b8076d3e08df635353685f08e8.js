"use client";let Button;module.link('./button',{default(v){Button=v}},0);module.link('./buttonHelpers',{"*":"*"},1);



module.exportDefault(Button);