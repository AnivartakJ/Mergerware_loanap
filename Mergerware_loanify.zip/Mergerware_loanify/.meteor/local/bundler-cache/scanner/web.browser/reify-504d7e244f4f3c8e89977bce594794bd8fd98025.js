module.export({default:()=>createTheme});let ThemeCache;module.link("./ThemeCache",{default(v){ThemeCache=v}},0);let Theme;module.link("./Theme",{default(v){Theme=v}},1);

var cacheThemes = new ThemeCache();

/**
 * Same as new Theme, but will always return same one if `derivative` not changed.
 */
function createTheme(derivatives) {
  var derivativeArr = Array.isArray(derivatives) ? derivatives : [derivatives];
  // Create new theme if not exist
  if (!cacheThemes.has(derivativeArr)) {
    cacheThemes.set(derivativeArr, new Theme(derivativeArr));
  }

  // Get theme from cache and return
  return cacheThemes.get(derivativeArr);
}