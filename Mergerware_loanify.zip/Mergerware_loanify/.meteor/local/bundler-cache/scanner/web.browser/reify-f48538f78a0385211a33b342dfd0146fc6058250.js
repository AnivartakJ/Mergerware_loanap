let _extends;module.link("@babel/runtime/helpers/esm/extends",{default(v){_extends=v}},0);let React;module.link('react',{"*"(v){React=v}},1);let CheckCircleFilledSvg;module.link("@ant-design/icons-svg/es/asn/CheckCircleFilled",{default(v){CheckCircleFilledSvg=v}},2);let AntdIcon;module.link("../components/AntdIcon",{default(v){AntdIcon=v}},3);
// GENERATE BY ./scripts/generate.ts
// DON NOT EDIT IT MANUALLY




var CheckCircleFilled = function CheckCircleFilled(props, ref) {
  return /*#__PURE__*/React.createElement(AntdIcon, _extends({}, props, {
    ref: ref,
    icon: CheckCircleFilledSvg
  }));
};
if (process.env.NODE_ENV !== 'production') {
  CheckCircleFilled.displayName = 'CheckCircleFilled';
}
module.exportDefault(React.forwardRef(CheckCircleFilled));