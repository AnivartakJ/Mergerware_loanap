let lintWarning;module.link("./utils",{lintWarning(v){lintWarning=v}},0);
var linter = function linter(key, value, info) {
  if (typeof value === 'string' && /NaN/g.test(value) || Number.isNaN(value)) {
    lintWarning("Unexpected 'NaN' in property '".concat(key, ": ").concat(value, "'."), info);
  }
};
module.exportDefault(linter);