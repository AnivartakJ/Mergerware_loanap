let React;module.link('react',{"*"(v){React=v}},0);let useRef;module.link('react',{useRef(v){useRef=v}},1);let animationEndName,transitionEndName;module.link("../util/motion",{animationEndName(v){animationEndName=v},transitionEndName(v){transitionEndName=v}},2);


module.exportDefault(function (callback) {
  var cacheElementRef = useRef();

  // Cache callback
  var callbackRef = useRef(callback);
  callbackRef.current = callback;

  // Internal motion event handler
  var onInternalMotionEnd = React.useCallback(function (event) {
    callbackRef.current(event);
  }, []);

  // Remove events
  function removeMotionEvents(element) {
    if (element) {
      element.removeEventListener(transitionEndName, onInternalMotionEnd);
      element.removeEventListener(animationEndName, onInternalMotionEnd);
    }
  }

  // Patch events
  function patchMotionEvents(element) {
    if (cacheElementRef.current && cacheElementRef.current !== element) {
      removeMotionEvents(cacheElementRef.current);
    }
    if (element && element !== cacheElementRef.current) {
      element.addEventListener(transitionEndName, onInternalMotionEnd);
      element.addEventListener(animationEndName, onInternalMotionEnd);

      // Save as cache in case dom removed trigger by `motionDeadline`
      cacheElementRef.current = element;
    }
  }

  // Clean up when removed
  React.useEffect(function () {
    return function () {
      removeMotionEvents(cacheElementRef.current);
    };
  }, []);
  return [patchMotionEvents, removeMotionEvents];
});