"use client";module.export({ANT_MARK:()=>ANT_MARK},true);let React;module.link('react',{"*"(v){React=v}},0);let devUseWarning;module.link('../_util/warning',{devUseWarning(v){devUseWarning=v}},1);let changeConfirmLocale;module.link('../modal/locale',{changeConfirmLocale(v){changeConfirmLocale=v}},2);let LocaleContext;module.link('./context',{default(v){LocaleContext=v}},3);module.link('./useLocale',{default:"useLocale"},4);






const ANT_MARK = 'internalMark';
const LocaleProvider = props => {
  const {
    locale = {},
    children,
    _ANT_MARK__
  } = props;
  if (process.env.NODE_ENV !== 'production') {
    const warning = devUseWarning('LocaleProvider');
    process.env.NODE_ENV !== "production" ? warning(_ANT_MARK__ === ANT_MARK, 'deprecated', '`LocaleProvider` is deprecated. Please use `locale` with `ConfigProvider` instead: http://u.ant.design/locale') : void 0;
  }
  React.useEffect(() => {
    const clearLocale = changeConfirmLocale(locale && locale.Modal);
    return clearLocale;
  }, [locale]);
  const getMemoizedContextValue = React.useMemo(() => Object.assign(Object.assign({}, locale), {
    exist: true
  }), [locale]);
  return /*#__PURE__*/React.createElement(LocaleContext.Provider, {
    value: getMemoizedContextValue
  }, children);
};
if (process.env.NODE_ENV !== 'production') {
  LocaleProvider.displayName = 'LocaleProvider';
}
module.exportDefault(LocaleProvider);