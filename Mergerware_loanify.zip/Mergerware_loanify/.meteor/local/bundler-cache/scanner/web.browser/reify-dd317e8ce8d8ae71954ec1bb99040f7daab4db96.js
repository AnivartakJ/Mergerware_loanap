module.export({inline:()=>inline,inlineMock:()=>inlineMock});var inline = false;
function inlineMock(nextInline) {
  if (typeof nextInline === 'boolean') {
    module.runSetters(inline = nextInline,["inline"]);
  }
  return inline;
}