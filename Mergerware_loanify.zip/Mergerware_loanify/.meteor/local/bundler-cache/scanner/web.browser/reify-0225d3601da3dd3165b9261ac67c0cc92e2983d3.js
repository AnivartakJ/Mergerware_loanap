module.export({default:()=>NumCalculator});let _classCallCheck;module.link("@babel/runtime/helpers/esm/classCallCheck",{default(v){_classCallCheck=v}},0);let _createClass;module.link("@babel/runtime/helpers/esm/createClass",{default(v){_createClass=v}},1);let _possibleConstructorReturn;module.link("@babel/runtime/helpers/esm/possibleConstructorReturn",{default(v){_possibleConstructorReturn=v}},2);let _isNativeReflectConstruct;module.link("@babel/runtime/helpers/esm/isNativeReflectConstruct",{default(v){_isNativeReflectConstruct=v}},3);let _getPrototypeOf;module.link("@babel/runtime/helpers/esm/getPrototypeOf",{default(v){_getPrototypeOf=v}},4);let _inherits;module.link("@babel/runtime/helpers/esm/inherits",{default(v){_inherits=v}},5);let AbstractCalculator;module.link('./calculator',{default(v){AbstractCalculator=v}},6);





function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }

let NumCalculator = /*#__PURE__*/function (_AbstractCalculator) {
  _inherits(NumCalculator, _AbstractCalculator);
  function NumCalculator(num) {
    var _this;
    _classCallCheck(this, NumCalculator);
    _this = _callSuper(this, NumCalculator);
    _this.result = 0;
    if (num instanceof NumCalculator) {
      _this.result = num.result;
    } else if (typeof num === 'number') {
      _this.result = num;
    }
    return _this;
  }
  _createClass(NumCalculator, [{
    key: "add",
    value: function add(num) {
      if (num instanceof NumCalculator) {
        this.result += num.result;
      } else if (typeof num === 'number') {
        this.result += num;
      }
      return this;
    }
  }, {
    key: "sub",
    value: function sub(num) {
      if (num instanceof NumCalculator) {
        this.result -= num.result;
      } else if (typeof num === 'number') {
        this.result -= num;
      }
      return this;
    }
  }, {
    key: "mul",
    value: function mul(num) {
      if (num instanceof NumCalculator) {
        this.result *= num.result;
      } else if (typeof num === 'number') {
        this.result *= num;
      }
      return this;
    }
  }, {
    key: "div",
    value: function div(num) {
      if (num instanceof NumCalculator) {
        this.result /= num.result;
      } else if (typeof num === 'number') {
        this.result /= num;
      }
      return this;
    }
  }, {
    key: "equal",
    value: function equal() {
      return this.result;
    }
  }]);
  return NumCalculator;
}(AbstractCalculator);
