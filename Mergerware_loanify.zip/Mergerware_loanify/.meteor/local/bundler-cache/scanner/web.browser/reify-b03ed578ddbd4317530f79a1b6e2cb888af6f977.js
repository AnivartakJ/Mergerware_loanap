"use client";let InternalAlert;module.link('./Alert',{default(v){InternalAlert=v}},0);let ErrorBoundary;module.link('./ErrorBoundary',{default(v){ErrorBoundary=v}},1);



const Alert = InternalAlert;
Alert.ErrorBoundary = ErrorBoundary;
module.exportDefault(Alert);