"use client";let React;module.link('react',{"*"(v){React=v}},0);let devUseWarning;module.link('../_util/warning',{devUseWarning(v){devUseWarning=v}},1);



/**
 * Warning for ConfigProviderProps.
 * This will be empty function in production.
 */
const PropWarning = /*#__PURE__*/React.memo(_ref => {
  let {
    dropdownMatchSelectWidth
  } = _ref;
  const warning = devUseWarning('ConfigProvider');
  warning.deprecated(dropdownMatchSelectWidth === undefined, 'dropdownMatchSelectWidth', 'popupMatchSelectWidth');
  return null;
});
if (process.env.NODE_ENV !== 'production') {
  PropWarning.displayName = 'PropWarning';
}
module.exportDefault(process.env.NODE_ENV !== 'production' ? PropWarning : () => null);