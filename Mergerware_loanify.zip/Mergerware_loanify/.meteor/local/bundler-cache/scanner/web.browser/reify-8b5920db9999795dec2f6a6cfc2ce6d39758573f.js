let enUS;module.link('../../date-picker/locale/en_US',{default(v){enUS=v}},0);
module.exportDefault(enUS);