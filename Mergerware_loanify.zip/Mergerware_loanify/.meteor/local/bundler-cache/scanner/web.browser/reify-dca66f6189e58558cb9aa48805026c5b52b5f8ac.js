module.export({default:()=>_toArray});let arrayWithHoles;module.link("./arrayWithHoles.js",{default(v){arrayWithHoles=v}},0);let iterableToArray;module.link("./iterableToArray.js",{default(v){iterableToArray=v}},1);let unsupportedIterableToArray;module.link("./unsupportedIterableToArray.js",{default(v){unsupportedIterableToArray=v}},2);let nonIterableRest;module.link("./nonIterableRest.js",{default(v){nonIterableRest=v}},3);



function _toArray(arr) {
  return arrayWithHoles(arr) || iterableToArray(arr) || unsupportedIterableToArray(arr) || nonIterableRest();
}