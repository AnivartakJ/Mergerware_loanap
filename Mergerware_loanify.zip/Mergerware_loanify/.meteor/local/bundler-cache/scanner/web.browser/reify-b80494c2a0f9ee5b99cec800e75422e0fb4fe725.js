let tinycolor;module.link('./index.js',{tinycolor(v){tinycolor=v}},0);module.link('./index.js',{"*":"*"},1);module.link('./css-color-names.js',{"*":"*"},2);module.link('./readability.js',{"*":"*"},3);module.link('./to-ms-filter.js',{"*":"*"},4);module.link('./from-ratio.js',{"*":"*"},5);module.link('./format-input.js',{"*":"*"},6);module.link('./random.js',{"*":"*"},7);module.link('./interfaces.js',{"*":"*"},8);module.link('./conversion.js',{"*":"*"},9);









// kept for backwards compatability with v1
module.exportDefault(tinycolor);
