let NumCalculator;module.link('./NumCalculator',{default(v){NumCalculator=v}},0);let CSSCalculator;module.link('./CSSCalculator',{default(v){CSSCalculator=v}},1);

const genCalc = type => {
  const Calculator = type === 'css' ? CSSCalculator : NumCalculator;
  return num => new Calculator(num);
};
module.exportDefault(genCalc);