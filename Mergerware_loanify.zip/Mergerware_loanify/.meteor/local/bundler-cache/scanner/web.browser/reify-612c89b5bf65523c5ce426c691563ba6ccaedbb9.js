module.export({default:()=>derivative});let generate;module.link('@ant-design/colors',{generate(v){generate=v}},0);let genControlHeight;module.link('../shared/genControlHeight',{default(v){genControlHeight=v}},1);let genSizeMapToken;module.link('../shared/genSizeMapToken',{default(v){genSizeMapToken=v}},2);let defaultPresetColors;module.link('../seed',{defaultPresetColors(v){defaultPresetColors=v}},3);let genColorMapToken;module.link('../shared/genColorMapToken',{default(v){genColorMapToken=v}},4);let genCommonMapToken;module.link('../shared/genCommonMapToken',{default(v){genCommonMapToken=v}},5);let generateColorPalettes,generateNeutralColorPalettes;module.link('./colors',{generateColorPalettes(v){generateColorPalettes=v},generateNeutralColorPalettes(v){generateNeutralColorPalettes=v}},6);let genFontMapToken;module.link('../shared/genFontMapToken',{default(v){genFontMapToken=v}},7);







function derivative(token) {
  const colorPalettes = Object.keys(defaultPresetColors).map(colorKey => {
    const colors = generate(token[colorKey]);
    return new Array(10).fill(1).reduce((prev, _, i) => {
      prev[`${colorKey}-${i + 1}`] = colors[i];
      prev[`${colorKey}${i + 1}`] = colors[i];
      return prev;
    }, {});
  }).reduce((prev, cur) => {
    prev = Object.assign(Object.assign({}, prev), cur);
    return prev;
  }, {});
  return Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, token), colorPalettes), genColorMapToken(token, {
    generateColorPalettes,
    generateNeutralColorPalettes
  })), genFontMapToken(token.fontSize)), genSizeMapToken(token)), genControlHeight(token)), genCommonMapToken(token));
}