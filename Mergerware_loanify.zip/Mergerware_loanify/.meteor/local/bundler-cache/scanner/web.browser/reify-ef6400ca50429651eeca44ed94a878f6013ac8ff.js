module.export({default:()=>_arrayWithHoles});function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}