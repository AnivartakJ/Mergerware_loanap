module.export({default:()=>CSSCalculator});let _classCallCheck;module.link("@babel/runtime/helpers/esm/classCallCheck",{default(v){_classCallCheck=v}},0);let _createClass;module.link("@babel/runtime/helpers/esm/createClass",{default(v){_createClass=v}},1);let _possibleConstructorReturn;module.link("@babel/runtime/helpers/esm/possibleConstructorReturn",{default(v){_possibleConstructorReturn=v}},2);let _isNativeReflectConstruct;module.link("@babel/runtime/helpers/esm/isNativeReflectConstruct",{default(v){_isNativeReflectConstruct=v}},3);let _getPrototypeOf;module.link("@babel/runtime/helpers/esm/getPrototypeOf",{default(v){_getPrototypeOf=v}},4);let _inherits;module.link("@babel/runtime/helpers/esm/inherits",{default(v){_inherits=v}},5);let AbstractCalculator;module.link('./calculator',{default(v){AbstractCalculator=v}},6);





function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }

const CALC_UNIT = 'CALC_UNIT';
function unit(value) {
  if (typeof value === 'number') {
    return `${value}${CALC_UNIT}`;
  }
  return value;
}
let CSSCalculator = /*#__PURE__*/function (_AbstractCalculator) {
  _inherits(CSSCalculator, _AbstractCalculator);
  function CSSCalculator(num) {
    var _this;
    _classCallCheck(this, CSSCalculator);
    _this = _callSuper(this, CSSCalculator);
    _this.result = '';
    if (num instanceof CSSCalculator) {
      _this.result = `(${num.result})`;
    } else if (typeof num === 'number') {
      _this.result = unit(num);
    } else if (typeof num === 'string') {
      _this.result = num;
    }
    return _this;
  }
  _createClass(CSSCalculator, [{
    key: "add",
    value: function add(num) {
      if (num instanceof CSSCalculator) {
        this.result = `${this.result} + ${num.getResult()}`;
      } else if (typeof num === 'number' || typeof num === 'string') {
        this.result = `${this.result} + ${unit(num)}`;
      }
      this.lowPriority = true;
      return this;
    }
  }, {
    key: "sub",
    value: function sub(num) {
      if (num instanceof CSSCalculator) {
        this.result = `${this.result} - ${num.getResult()}`;
      } else if (typeof num === 'number' || typeof num === 'string') {
        this.result = `${this.result} - ${unit(num)}`;
      }
      this.lowPriority = true;
      return this;
    }
  }, {
    key: "mul",
    value: function mul(num) {
      if (this.lowPriority) {
        this.result = `(${this.result})`;
      }
      if (num instanceof CSSCalculator) {
        this.result = `${this.result} * ${num.getResult(true)}`;
      } else if (typeof num === 'number' || typeof num === 'string') {
        this.result = `${this.result} * ${num}`;
      }
      this.lowPriority = false;
      return this;
    }
  }, {
    key: "div",
    value: function div(num) {
      if (this.lowPriority) {
        this.result = `(${this.result})`;
      }
      if (num instanceof CSSCalculator) {
        this.result = `${this.result} / ${num.getResult(true)}`;
      } else if (typeof num === 'number' || typeof num === 'string') {
        this.result = `${this.result} / ${num}`;
      }
      this.lowPriority = false;
      return this;
    }
  }, {
    key: "getResult",
    value: function getResult(force) {
      return this.lowPriority || force ? `(${this.result})` : this.result;
    }
  }, {
    key: "equal",
    value: function equal(options) {
      const {
        unit: cssUnit = true
      } = options || {};
      const regexp = new RegExp(`${CALC_UNIT}`, 'g');
      this.result = this.result.replace(regexp, cssUnit ? 'px' : '');
      if (typeof this.lowPriority !== 'undefined') {
        return `calc(${this.result})`;
      }
      return this.result;
    }
  }]);
  return CSSCalculator;
}(AbstractCalculator);
