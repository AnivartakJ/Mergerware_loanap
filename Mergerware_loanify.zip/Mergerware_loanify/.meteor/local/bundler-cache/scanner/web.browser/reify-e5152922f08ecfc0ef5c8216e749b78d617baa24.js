module.export({ModalContext:()=>ModalContext,ModalContextProvider:()=>ModalContextProvider},true);let React;module.link('react',{default(v){React=v}},0);
const ModalContext = /*#__PURE__*/React.createContext({});
const {
  Provider: ModalContextProvider
} = ModalContext;