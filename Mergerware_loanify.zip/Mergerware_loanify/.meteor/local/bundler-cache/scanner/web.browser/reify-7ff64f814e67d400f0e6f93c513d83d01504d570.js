module.export({lintWarning:()=>lintWarning});let devWarning;module.link("rc-util/es/warning",{default(v){devWarning=v}},0);
function lintWarning(message, info) {
  var path = info.path,
    parentSelectors = info.parentSelectors;
  devWarning(false, "[Ant Design CSS-in-JS] ".concat(path ? "Error in ".concat(path, ": ") : '').concat(message).concat(parentSelectors.length ? " Selector: ".concat(parentSelectors.join(' | ')) : ''));
}