module.export({PresetColors:()=>PresetColors,genComponentStyleHook:()=>genComponentStyleHook,genSubStyleComponent:()=>genSubStyleComponent,genPresetColor:()=>genPresetColor,genStyleHooks:()=>genStyleHooks,mergeToken:()=>mergeToken,statisticToken:()=>statisticToken,calc:()=>calc,getLineHeight:()=>getLineHeight,useResetIconStyle:()=>useResetIconStyle,useStyleRegister:()=>useStyleRegister,useToken:()=>useToken});let useStyleRegister;module.link('@ant-design/cssinjs',{useStyleRegister(v){useStyleRegister=v}},0);let PresetColors;module.link('./interface',{PresetColors(v){PresetColors=v}},1);let useToken;module.link('./useToken',{default(v){useToken=v}},2);let genComponentStyleHook,genSubStyleComponent,genStyleHooks;module.link('./util/genComponentStyleHook',{default(v){genComponentStyleHook=v},genSubStyleComponent(v){genSubStyleComponent=v},genStyleHooks(v){genStyleHooks=v}},3);let genPresetColor;module.link('./util/genPresetColor',{default(v){genPresetColor=v}},4);let statisticToken,mergeToken;module.link('./util/statistic',{default(v){statisticToken=v},merge(v){mergeToken=v}},5);let useResetIconStyle;module.link('./util/useResetIconStyle',{default(v){useResetIconStyle=v}},6);let calc;module.link('./util/calc',{default(v){calc=v}},7);let getLineHeight;module.link('./themes/shared/genFontSizes',{getLineHeight(v){getLineHeight=v}},8);module.link('./context',{DesignTokenContext:"DesignTokenContext",defaultConfig:"defaultConfig"},9);











