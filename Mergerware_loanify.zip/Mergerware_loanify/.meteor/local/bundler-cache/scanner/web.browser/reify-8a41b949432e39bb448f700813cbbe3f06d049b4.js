"use client";let React,useContext;module.link('react',{default(v){React=v},useContext(v){useContext=v}},0);let ActionButton;module.link('../../_util/ActionButton',{default(v){ActionButton=v}},1);let ModalContext;module.link('../context',{ModalContext(v){ModalContext=v}},2);




const ConfirmOkBtn = () => {
  const {
    autoFocusButton,
    close,
    isSilent,
    okButtonProps,
    rootPrefixCls,
    okTextLocale,
    okType,
    onConfirm,
    onOk
  } = useContext(ModalContext);
  return /*#__PURE__*/React.createElement(ActionButton, {
    isSilent: isSilent,
    type: okType || 'primary',
    actionFn: onOk,
    close: function () {
      close === null || close === void 0 ? void 0 : close.apply(void 0, arguments);
      onConfirm === null || onConfirm === void 0 ? void 0 : onConfirm(true);
    },
    autoFocus: autoFocusButton === 'ok',
    buttonProps: okButtonProps,
    prefixCls: `${rootPrefixCls}-btn`
  }, okTextLocale);
};
module.exportDefault(ConfirmOkBtn);