let useContext;module.link('react',{useContext(v){useContext=v}},0);let DisabledContext;module.link('../DisabledContext',{default(v){DisabledContext=v}},1);let SizeContext;module.link('../SizeContext',{default(v){SizeContext=v}},2);


function useConfig() {
  const componentDisabled = useContext(DisabledContext);
  const componentSize = useContext(SizeContext);
  return {
    componentDisabled,
    componentSize
  };
}
module.exportDefault(useConfig);