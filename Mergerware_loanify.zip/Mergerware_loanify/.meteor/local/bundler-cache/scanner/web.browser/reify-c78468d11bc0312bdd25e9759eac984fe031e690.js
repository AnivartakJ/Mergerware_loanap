let createContext;module.link('react',{createContext(v){createContext=v}},0);
const LocaleContext = /*#__PURE__*/createContext(undefined);
module.exportDefault(LocaleContext);