const locale = {
  placeholder: 'Select time',
  rangePlaceholder: ['Start time', 'End time']
};
module.exportDefault(locale);