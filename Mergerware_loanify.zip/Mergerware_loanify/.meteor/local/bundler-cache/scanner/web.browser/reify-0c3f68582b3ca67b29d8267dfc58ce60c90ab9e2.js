"use client";let InternalAnchor;module.link('./Anchor',{default(v){InternalAnchor=v}},0);let AnchorLink;module.link('./AnchorLink',{default(v){AnchorLink=v}},1);



const Anchor = InternalAnchor;
Anchor.Link = AnchorLink;
module.exportDefault(Anchor);